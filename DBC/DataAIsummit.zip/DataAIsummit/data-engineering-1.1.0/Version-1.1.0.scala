// Databricks notebook source
// MAGIC 
// MAGIC %md # Course: data-engineering
// MAGIC * Version 1.1.0
// MAGIC * Built 2020-09-24 16:49:41 UTC
// MAGIC * Git revision: a06606902ae629bef9d24c7f08140ad502b952df
// MAGIC 
// MAGIC Copyright © 2020 Databricks, Inc.